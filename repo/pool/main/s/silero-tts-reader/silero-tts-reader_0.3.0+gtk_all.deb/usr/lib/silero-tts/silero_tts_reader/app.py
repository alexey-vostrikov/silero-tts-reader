"""Главный контроллер приложения — связывает компоненты (GTK3 / PyGObject).

Переписано с Qt на GTK: ``QApplication`` → ``Gtk.Application``, ``pyqtSignal`` →
``GLib.idle_add`` (все обновления интерфейса из рабочих потоков проходят через
``_ui()``), ``QTimer`` → ``GLib.timeout_add``, ``QSystemTrayIcon.showMessage`` →
``Gio.Notification``, ``QMessageBox`` → ``Gtk.MessageDialog``.
"""
from __future__ import annotations

import contextlib
import os
import queue
import signal
import threading
import traceback
from collections.abc import Callable
from pathlib import Path

# Подавить шум pynput/Xlib до любых импортов
os.environ.setdefault("PYNPUT_BACKEND", "xorg")

import gi

gi.require_version("Gdk", "4.0")
gi.require_version("Gio", "2.0")
gi.require_version("Gtk", "4.0")

from gi.repository import Gdk, Gio, GLib, Gtk  # noqa: E402

from . import (  # noqa: E402
    build_info,
    i18n,
    instance,
    log,
)
from .config.config_manager import ConfigManager  # noqa: E402
from .core.abbrev import load_extra as load_abbrev_extra  # noqa: E402
from .core.accent import load_overrides  # noqa: E402
from .core.audio_player import AudioPlayer  # noqa: E402
from .core.hotkey_listener import HotkeyListener  # noqa: E402
from .core.text_extractor import TextExtractor  # noqa: E402
from .core.text_processor import TextProcessor  # noqa: E402,F401  (нужен для настроек)
from .core.tts_engine import TTSEngine, TTSLoadError  # noqa: E402
from .core.tts_worker import TTSWorker  # noqa: E402
from .i18n import _  # noqa: E402
from .run_options import RunOptions  # noqa: E402
from .ui import window_icon  # noqa: E402
from .ui.abbrev_window import AbbrevWindow  # noqa: E402
from .ui.playback_widget import PlaybackWidget  # noqa: E402
from .ui.settings_window import SettingsWindow  # noqa: E402
from .ui.sni_tray import MenuEntry, StatusNotifierTray  # noqa: E402
from .ui.theme_manager import ThemeManager  # noqa: E402
from .ui.tray_icons import icon_name as tray_icon_name  # noqa: E402
from .ui.window_icon import icon_file  # noqa: E402

# Идентификатор приложения задан в ui/window_icon.py: он же используется как
# имя .desktop-файла и WM_CLASS, иначе рабочий стол не находит иконку.
APP_ID = window_icon.APP_ID

# Сколько сегментов держим готовыми к воспроизведению. Ограничение даёт
# обратное давление: синтез не убегает вперёд и не держит в памяти всю книгу
# (у большой книги это часы звука), а идёт в темпе проигрывания.
AUDIO_QUEUE_SIZE = 6
APP_NAME = "Silero TTS Reader"
APP_VERSION = "1.0.0"



class Application(Gtk.Application):
    """Приложение целиком: конфиг, движок, плеер, трей и настройки."""

    def __init__(self, argv: list[str], options: RunOptions | None = None) -> None:
        # HANDLES_OPEN: `silero-tts-reader текст.txt`, «Открыть с помощью» и
        # перетаскивание файла на иконку приходят в do_open, а не в activate.
        super().__init__(
            application_id=APP_ID,
            flags=Gio.ApplicationFlags.HANDLES_OPEN,
        )
        self._argv = list(argv)
        # Ограничения только на этот запуск: --max-time и --exit-after-play.
        self._options = options or RunOptions()
        self._max_time_source: int | None = None
        self._initialized = False

        self._config = ConfigManager()
        # Язык интерфейса поднимаем до любых строк: _() ниже опирается на него.
        i18n.init(self._config.ui_language)
        self._extractor = TextExtractor()
        self._engine = TTSEngine(
            sample_rate=self._config.sample_rate,
            models=self._config.models,
            accent_mode=self._config.stress_dict,
            accent_overrides=load_overrides(self._config.stress_file),
            abbreviations=self._config.abbreviations,
            abbreviations_extra=load_abbrev_extra(self._config.abbrev_file),
            stress_source=self._config.stress_source,
        )
        self._hotkey_listener = HotkeyListener()
        self._stop_event = threading.Event()
        self._player: AudioPlayer | None = None
        self._worker: TTSWorker | None = None
        self._audio_queue: queue.Queue = queue.Queue(maxsize=AUDIO_QUEUE_SIZE)

        self._theme_manager: ThemeManager | None = None
        self._widget: PlaybackWidget | None = None
        self._tray: StatusNotifierTray | None = None
        self._settings_dialog: SettingsWindow | None = None
        # Окно редактора сокращений: держим ссылку, иначе диалог соберётся
        # сборщиком мусора сразу после показа.
        self._abbrev_dialog: AbbrevWindow | None = None
        # Ссылка на открытый диалог выбора файла обязательна: без неё
        # Gtk.FileChooserNative освобождается и не показывается.
        self._file_chooser = None
        # Ссылка на окно «О программе»: без неё GTK4-диалог освобождается
        # сборщиком мусора и не появляется.
        self._about_dialog = None
        self._position_timer: int | None = None

    # ── Жизненный цикл ───────────────────────────────────────────────────────

    def do_startup(self) -> None:
        Gtk.Application.do_startup(self)
        self.hold()  # приложение живёт в трее, а не окном
        self._setup_actions()

    def do_activate(self) -> None:
        Gtk.Application.do_activate(self)

        # Второй запуск не должен создавать второй трей, вторую копию модели и
        # заново вешать хоткеи: GApplication передаёт его сюда же, в тот же
        # процесс. Раньше do_activate отрабатывал целиком, и каждая комбинация
        # срабатывала дважды, а libayatana ругался «Объект уже экспортирован».
        if self._initialized:
            log.info("Приложение уже запущено — поднимаю виджет")
            if self._widget is not None:
                self._widget.fade_in()
            return
        self._initialized = True

        # Себя отмечаем как работающий экземпляр: следующий запуск сравнит
        # метки сборки и, если он новее, заменит нас.
        instance.register(build_info.current())

        self._theme_manager = ThemeManager()
        # Глобальное позиционирование выключено по умолчанию: место окна
        # выбирает композитор. Включается на вкладке «Позиционирование».
        self._widget = PlaybackWidget(application=self,
                                      positioning=self._config.window_positioning)
        self._widget.restore_position(*self._config.widget_position)
        self._wire_widget()
        # Окно привязываем к приложению: иначе действия app.* из меню не найдутся
        self.add_window(self._widget)
        self._widget.set_menu_model(self.build_menu_model())

        self._theme_manager.connect("theme-changed", lambda *_: self._update_widget_theme())
        self._theme_manager.connect("accent-changed", lambda *_: self._update_widget_theme())
        self._theme_manager.use_system_accent = self._config.use_system_accent
        self._theme_manager.set_mode(self._config.theme)
        self._update_widget_theme()

        # Значок в лотке — через StatusNotifierItem: в GTK4 Gtk.StatusIcon и
        # Gtk.Menu удалены, а привязка AppIndicator собрана под GTK3.
        # Значок трея — отдельный монохромный рисунок: цветная иконка приложения
        # на тёмной панели выглядит ярким пятном, на светлой — тёмным.
        self._tray = StatusNotifierTray(
            icon_name=tray_icon_name(self._config.tray_icon),
            title=APP_NAME,
            on_activate=self._show_window,
        )
        self._tray.set_entries([
            MenuEntry(_("🔊  Показать окно"), self._show_window),
            MenuEntry(_("📂  Открыть файл…"), self._open_file_dialog),
            MenuEntry(separator=True),
            MenuEntry(_("📋  Озвучить буфер обмена"), self._on_speak_clipboard),
            MenuEntry(separator=True),
            MenuEntry(_("⚙️  Настройки"), self._open_settings),
            MenuEntry(_("ℹ️  О программе"), self._show_about),
            MenuEntry(separator=True),
            MenuEntry(_("✖  Выход"), self._quit),
        ])
        self._tray.show()
        if not self._tray.available:
            print(_(
                "  ⚠ Иконка в трее недоступна: в системе нет службы значков\n"
                "    (в GNOME это расширение AppIndicator Support). Сообщения идут\n"
                "    уведомлениями, управление — из окна и с горячих клавиш."
            ), flush=True)

        print(
            _("\n✓ Silero TTS Reader запущен")
            + _("\n  Горячие клавиши:")
            + _("\n    Озвучить выделенное : {hotkey}").format(
                hotkey=self._config.hotkey_speak_selection)
            + _("\n    Озвучить буфер      : {hotkey}").format(
                hotkey=self._config.hotkey_speak_clipboard)
            + _("\n    Стоп                : {hotkey}").format(
                hotkey=self._config.hotkey_stop)
            + _("\n  Иконка в трее — правая кнопка мыши для меню")
            + _("\n  Нажмите Ctrl+C в терминале для выхода\n")
            + "\n  " + _("Язык интерфейса: {language}").format(
                language=i18n.language_name())
            + "\n  " + _("Сборка: {build}").format(
                build=build_info.current().describe()),
            flush=True,
        )

        self._install_signal_handlers()
        self._register_hotkeys()
        self._load_engine()

        # Сохранять позицию виджета раз в 2 секунды
        self._position_timer = GLib.timeout_add(2000, self._save_widget_position)

    # ── Действия и горячие клавиши внутри приложения ─────────────────────────

    def _setup_actions(self) -> None:
        """Действия приложения и их сочетания клавиш.

        Глобальные хоткеи на Wayland без evdev недоступны, а эти работают,
        пока окно виджета в фокусе: без них при таком окружении приложением
        нельзя управлять вообще.
        """
        actions = {
            "open-file": (self._open_file_dialog, ["<Control>o"]),
            "settings": (self._open_settings, ["<Control>comma"]),
            "abbreviations": (self.open_abbreviations, []),
            "about": (self._show_about, []),
            "quit": (self._quit, ["<Control>q"]),
            "speak-clipboard": (self._on_speak_clipboard, ["<Control><Shift>c"]),
            "speak-selection": (
                lambda: self._ui(self._start_tts, "__selection__"),
                ["<Control><Shift>r"],
            ),
            "stop": (self._stop_playback, ["<Control><Shift>s"]),
        }
        for name, (callback, accels) in actions.items():
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", lambda _a, _p, cb=callback: cb())
            self.add_action(action)
            if accels:
                self.set_accels_for_action(f"app.{name}", accels)

    def build_menu_model(self) -> Gio.Menu:
        """Меню для виджета: те же действия, что и клавиши."""
        menu = Gio.Menu()
        menu.append(_("Открыть файл…"), "app.open-file")
        menu.append(_("Озвучить буфер обмена"), "app.speak-clipboard")
        menu.append(_("Озвучить выделенное"), "app.speak-selection")
        menu.append(_("Остановить"), "app.stop")
        section = Gio.Menu()
        section.append(_("Сокращения…"), "app.abbreviations")
        section.append(_("Настройки"), "app.settings")
        section.append(_("О программе"), "app.about")
        menu.append_section(None, section)
        tail = Gio.Menu()
        tail.append(_("Выход"), "app.quit")
        menu.append_section(None, tail)
        return menu

    # ── Открытие файлов ──────────────────────────────────────────────────────

    def do_open(self, files, n_files: int, _hint: str) -> None:
        """Озвучить открытые файлы: аргумент командной строки или «Открыть с помощью»."""
        if not self._initialized:
            self.do_activate()
        self._speak_paths([gfile.get_path() for gfile in files])

    def _open_file_dialog(self) -> None:
        """Выбрать файл или книгу через диалог и озвучить.

        ``Gtk.FileChooserNative`` вместо FileChooserDialog: под Wayland окно
        рисует портал, и оно не привязано к нашему окну (у виджета
        ``skip_taskbar`` и прозрачность — обычный диалог поверх него выглядит
        сломанным).
        """
        if not self._initialized:
            self.do_activate()

        # Второй диалог поверх первого — это три-четыре одинаковых окна:
        # портал рисует их сам, и они не связаны с нашим. Пока один открыт,
        # повторное нажатие только поднимает его.
        if self._file_chooser is not None:
            self._file_chooser.show()
            return

        chooser = Gtk.FileChooserNative.new(
            _("Открыть файл для озвучки"),
            self._widget,
            Gtk.FileChooserAction.OPEN,
            _("Озвучить"),
            _("Отмена"),
        )

        # Фильтры: сначала книги (основной случай), затем текст, затем всё.
        books = Gtk.FileFilter()
        books.set_name(_("Книги FB2"))
        for suffix in TextExtractor.BOOK_SUFFIXES:
            books.add_pattern(f"*{suffix}")
        chooser.add_filter(books)

        texts = Gtk.FileFilter()
        texts.set_name(_("Текстовые файлы"))
        for suffix in TextExtractor.TEXT_SUFFIXES:
            texts.add_pattern(f"*{suffix}")
        chooser.add_filter(texts)

        every = Gtk.FileFilter()
        every.set_name(_("Все файлы"))
        every.add_pattern("*")
        chooser.add_filter(every)
        chooser.set_filter(books)

        # Папка из настроек: обычно книги лежат в одном месте.
        # В GTK4 метод ждёт Gio.File: со строкой он падает TypeError прямо в
        # обработчике нажатия, и диалог не появляется вовсе.
        last_dir = self._config.last_file_dir
        if last_dir:
            with contextlib.suppress(GLib.Error):
                chooser.set_current_folder(Gio.File.new_for_path(last_dir))

        # Ссылка обязательна. Gtk.FileChooserNative живёт, пока на него есть
        # ссылка из Python: локальная переменная исчезает при выходе из
        # функции, сборщик мусора освобождает диалог, и он не появляется —
        # ни ошибки, ни окна. Проверено отдельным опытом: после del + gc
        # в списке окон остаётся только главное.
        self._file_chooser = chooser

        def on_response(dialog, response):
            path = None
            if response == Gtk.ResponseType.ACCEPT:
                gfile = dialog.get_file()
                path = gfile.get_path() if gfile else None
            dialog.destroy()
            self._file_chooser = None
            if path:
                self._remember_dir(path)
                self._speak_paths([path])

        chooser.connect("response", on_response)
        chooser.show()

    def _remember_dir(self, path: str) -> None:
        """Запомнить папку выбранного файла — в следующий раз диалог откроется в ней."""
        parent = str(Path(path).expanduser().parent)
        if self._config.last_file_dir == parent:
            return
        try:
            self._config.last_file_dir = parent
            self._config.save()
        except (OSError, AttributeError):
            pass  # настройка не критична: диалог просто откроется в домашней

    def _speak_paths(self, paths: list[str | None]) -> None:
        """Прочитать файлы и передать текст в синтез. Общий путь для всех входов."""
        texts: list[str] = []
        for path in paths:
            if not path:
                self._notify(_("Не удалось открыть файл"))
                continue
            try:
                texts.append(TextExtractor.read_text_file(path))
            except (OSError, ValueError) as exc:
                self._notify(str(exc))
        if not texts:
            return

        text = "\n\n".join(texts).strip()
        if not text:
            self._notify(_("Файл пустой"))
            return
        # Длинный текст не обрезаем и не спрашиваем: он читается целиком,
        # кусками по предложениям, а очередь синтеза ограничена — книга
        # уходит в динамик по мере готовности, а не копится в памяти.
        self._ui(self._start_tts, text)

    def _install_signal_handlers(self) -> None:
        """Штатный выход по SIGTERM: так нас просит закрыться новый экземпляр.

        Без обработчика процесс умирает мгновенно, не сохранив конфиг и не сняв
        иконку с шины, а следующий запуск получает занятое имя D-Bus.
        """
        try:
            # GLib.unix_signal_add в PyGObject 3.50+ объявлен устаревшим:
            # обработчик переехал в GLibUnix.signal_add. Берём новый, если он
            # есть, иначе остаётся старый.
            try:
                from gi.repository import GLibUnix

                add = GLibUnix.signal_add
            except (ImportError, AttributeError):
                add = GLib.unix_signal_add
            add(GLib.PRIORITY_HIGH, signal.SIGTERM, self._on_sigterm)
            add(GLib.PRIORITY_HIGH, signal.SIGINT, self._on_sigterm)
        except Exception:
            pass  # не критично: остаётся обычное поведение по умолчанию

    def _on_sigterm(self) -> bool:
        log.info("Получен сигнал завершения — закрываюсь")
        instance.clear()
        self._quit()
        return False  # одноразовый обработчик

    # ── Поток → интерфейс ────────────────────────────────────────────────────

    def _ui(self, func: Callable, *args) -> None:
        """Выполнить функцию в главном потоке GLib (замена сигналов Qt)."""
        GLib.idle_add(self._ui_call, func, args)

    @staticmethod
    def _ui_call(func: Callable, args: tuple) -> bool:
        try:
            func(*args)
        except Exception:
            traceback.print_exc()
        return False  # одноразовый вызов

    # ── Загрузка модели ──────────────────────────────────────────────────────

    def _load_engine(self) -> None:
        def _load() -> None:
            try:
                log.info("Загружаю модель TTS...")
                self._engine.load()
                speakers = self._engine.get_available_speakers()
                if self._config.speaker not in speakers and speakers:
                    self._config.speaker = speakers[0]
                    self._config.save()
                print("  ✓ " + _("Модель загружена. Голос: {voice}").format(
                      voice=self._config.speaker), flush=True)
                print("    " + _("Доступные голоса: {voices}").format(
                      voices=", ".join(speakers)), flush=True)
                # Английская модель необязательна: без неё латиница читается
                # русскими фонемами, о чём честнее сказать сразу.
                english = self._engine.get_available_speakers("en")
                if english:
                    print(
                        "  ✓ "
                        + _("Английская модель: голос {voice}, голосов {count}").format(
                            voice=self._config.speaker_for("en"), count=len(english)
                        ),
                        flush=True,
                    )
                else:
                    print("  ⚠ Английской модели нет: латиница будет читаться по-русски."
                          "\n    Скачать: silero-tts-model download en", flush=True)
            except TTSLoadError as exc:
                print("  ✗ " + _("Ошибка: {error}").format(error=exc), flush=True)
                self._ui(self._show_tts_error, str(exc))

        threading.Thread(target=_load, daemon=True, name="ModelLoader").start()

    # ── Виджет воспроизведения ───────────────────────────────────────────────

    def _show_window(self) -> None:
        """Вернуть виджет на экран.

        Виджет скрывается сам через ``schedule_hide``, и вернуть его можно
        только явно: ``fade_in`` снимает таймер скрытия и показывает окно.
        """
        if not self._initialized:
            self.do_activate()
            return
        if self._widget is not None:
            self._widget.fade_in()

    def _wire_widget(self) -> None:
        assert self._widget is not None
        w = self._widget
        w.on_open_file = self._open_file_dialog
        w.on_pause_resume = self._toggle_pause
        w.on_stop = self._stop_playback
        w.on_speed_changed = self._on_speed_changed
        w.on_previous = self._on_previous_quant
        w.on_next = self._on_next_quant
        w.on_rewind = self._on_rewind_playback
        w.on_seek_fraction = self._on_seek_fraction_playback

    def _update_widget_theme(self) -> None:
        if self._widget is None or self._theme_manager is None:
            return
        self._widget.apply_theme(
            is_dark=self._theme_manager.is_dark(),
            accent_color=self._theme_manager.accent_color(),
        )

    # ── Горячие клавиши ──────────────────────────────────────────────────────

    def _register_hotkeys(self) -> None:
        # Конфликт комбинаций разбирается в настройках, а не роняет запуск.
        with contextlib.suppress(ValueError):
            self._hotkey_listener.set_hotkeys(
                speak_selection=self._config.hotkey_speak_selection,
                speak_clipboard=self._config.hotkey_speak_clipboard,
                stop=self._config.hotkey_stop,
                on_speak_selection=lambda: self._ui(self._start_tts, "__selection__"),
                on_speak_clipboard=lambda: self._ui(self._on_speak_clipboard),
                on_stop=lambda: self._ui(self._stop_playback),
            )

    # ── Конвейер TTS ─────────────────────────────────────────────────────────

    def _start_tts(self, text_or_marker: str) -> None:
        if text_or_marker == "__selection__":
            text = self._extractor.get_selected_text()
            if not text:
                self._notify(_("Текст не выделен"))
                return
        else:
            text = text_or_marker

        self._stop_playback_sync()
        self._begin_pipeline(text)

    def _begin_pipeline(
        self,
        text: str,
        speaker: str | None = None,
        speed: float | None = None,
    ) -> None:
        if not self._engine.is_loaded:
            self._notify(_("Модель TTS ещё загружается, подождите..."))
            return

        self._stop_event = threading.Event()
        self._audio_queue = queue.Queue(maxsize=AUDIO_QUEUE_SIZE)
        use_speed = speed if speed is not None else self._config.speed
        use_speaker = speaker if speaker is not None else self._config.speakers

        # Общее число квантов известно заранее: по нему полоска показывает место
        # в книге, а не долю текущего предложения.
        total_quanta = TTSWorker.count_quanta(text)
        self._player = AudioPlayer(
            audio_queue=self._audio_queue,
            stop_event=self._stop_event,
            sample_rate=self._config.sample_rate,
            speed=use_speed,
            total_segments=total_quanta,
            on_started=lambda: self._ui(self._on_playback_started),
            on_segment_progress=lambda v: self._ui(self._on_segment_progress, v),
            on_segment_text=lambda t: self._ui(self._on_segment_text, t),
            on_paused=lambda: self._ui(self._on_playback_paused),
            on_resumed=lambda: self._ui(self._on_playback_resumed),
            on_finished=lambda: self._ui(self._on_playback_finished),
            on_stopped=lambda: self._ui(self._on_playback_stopped),
            on_speed_unavailable=lambda: self._ui(
                self._notify, "Изменение скорости недоступно (нет rubberband)"
            ),
        )

        self._worker = TTSWorker(
            engine=self._engine,
            text=text,
            speaker=use_speaker,
            config=self._config,
            audio_queue=self._audio_queue,
            stop_event=self._stop_event,
            on_error=lambda e: self._ui(self._show_tts_error, e),
        )

        # Окно сразу: первый квант синтезируется секунду-две, и всё это время
        # человек должен видеть, что приложение работает и что читается.
        if self._widget is not None:
            self._widget.fade_in()

        self._worker.start()
        self._player.start()

    def _refresh_tray_icon(self) -> None:
        """Переставить значок после смены варианта цвета в настройках."""
        if self._tray is None:
            return
        self._tray.set_icon_name(tray_icon_name(self._config.tray_icon))

    def _on_playback_started(self) -> None:
        self._arm_max_time()
        if self._widget is None:
            return
        # Окно уже показано в _begin_pipeline: повторный fade_in переставлял
        # его и печатал «Окно показано» дважды.
        self._widget.set_paused(False)

    def _arm_max_time(self) -> None:
        """Поставить ограничение по времени, если задан --max-time.

        Ограничение — на ВСЁ воспроизведение, а не на квант: таймер ставится
        один раз, когда звук начался, и по его срабатыванию чтение
        останавливается целиком. Отсчёт от начала звука, а не от запуска
        приложения: загрузка модели и первый синтез занимают секунды, и в них
        ограничение не должно тратиться. Время на паузах тоже считается —
        это срок отладочного прогона, а не секундомер прослушивания.
        """
        limit = self._options.max_time
        if limit is None or self._max_time_source is not None:
            return
        self._max_time_source = GLib.timeout_add(int(limit * 1000), self._on_max_time)

    def _disarm_max_time(self) -> None:
        """Снять таймер ограничения: чтение закончилось раньше срока."""
        if self._max_time_source is not None:
            GLib.source_remove(self._max_time_source)
            self._max_time_source = None

    def _on_max_time(self) -> bool:
        """Срок --max-time вышел: остановить чтение (и выйти, если просили)."""
        self._max_time_source = None
        # i18n: нет перевода — строка журнала в консоли
        log.info(f"Отладка: прошло {self._options.max_time:g} с — останавливаю чтение")
        self._stop_playback_sync()
        if self._widget is not None:
            self._widget.schedule_hide(500)
        if self._options.exit_after_play:
            GLib.timeout_add(200, self._quit_after_play)
        return False   # одноразовый таймер

    def _quit_after_play(self) -> bool:
        """--exit-after-play: завершить приложение после чтения."""
        # i18n: нет перевода — строка журнала в консоли
        log.info("Отладка: чтение закончено — выхожу")
        self._quit()
        return False

    def _on_segment_text(self, text: str) -> None:
        """Показать фразу, которую синтез получил: с разметкой и сокращениями."""
        if self._widget is not None:
            self._widget.set_segment_text(text)

    def _on_segment_progress(self, value: float) -> None:
        if self._widget is not None:
            self._widget.set_progress(value)

    def _on_playback_finished(self) -> None:
        self._disarm_max_time()
        if self._widget is not None:
            self._widget.set_paused(False)
            self._widget.schedule_hide(2000)
        if self._options.exit_after_play:
            # Небольшая пауза: окно должно успеть скрыться, иначе выход
            # выглядит как падение на середине фразы.
            GLib.timeout_add(400, self._quit_after_play)

    def _on_playback_stopped(self) -> None:
        self._disarm_max_time()
        if self._widget is not None:
            self._widget.schedule_hide(500)

    def _stop_playback(self) -> None:
        self._stop_event.set()

    def _stop_playback_sync(self) -> None:
        self._stop_event.set()
        if self._player and self._player.is_alive():
            self._player.join(timeout=1.0)

    def _on_playback_paused(self) -> None:
        if self._widget is not None:
            self._widget.set_paused(True)

    def _on_playback_resumed(self) -> None:
        if self._widget is not None:
            self._widget.set_paused(False)

    def _toggle_pause(self) -> None:
        if self._player is None:
            return
        if self._player.is_paused:
            self._player.resume()
        else:
            self._player.pause()

    def _on_previous_quant(self) -> None:
        """Предыдущая фраза: если текущая почти не звучала — шаг назад."""
        if self._player and self._player.is_alive():
            self._player.previous_quant()

    def _on_next_quant(self) -> None:
        """Следующая фраза: если до конца текущей мало — сразу переходим."""
        if self._player and self._player.is_alive():
            self._player.next_quant()

    def _on_rewind_playback(self, seconds: float) -> None:
        if self._player and self._player.is_alive():
            print(f"[SileroApp] Перемотка аудио на {seconds:+.1f} сек", flush=True)
            self._player.seek_relative(seconds)

    def _on_seek_fraction_playback(self, fraction: float) -> None:
        if self._player and self._player.is_alive():
            print(f"[SileroApp] Переход к позиции {fraction * 100:.1f}%", flush=True)
            self._player.seek_fraction(fraction)

    # ── Буфер обмена ─────────────────────────────────────────────────────────

    def _on_speak_clipboard(self) -> None:
        text = self._extractor.get_clipboard_text()
        if not text:
            self._notify(_("Буфер обмена не содержит текст"))
            return
        self._start_tts(text)

    # ── Скорость ─────────────────────────────────────────────────────────────

    def _on_speed_changed(self, speed: float) -> None:
        self._config.speed = speed
        self._config.save()
        if self._player and self._player.is_alive():
            self._player.set_speed(speed)

    # ── Настройки ────────────────────────────────────────────────────────────

    def _open_settings(self) -> None:
        if self._settings_dialog is not None:
            self._settings_dialog.present()
            return

        speakers: dict[str, list[str]] = {}
        if self._engine.is_loaded:
            speakers = {
                lang: voices
                for lang in self._engine.loaded_languages
                if (voices := self._engine.get_available_speakers(lang))
            }
        dialog = SettingsWindow(
            config=self._config,
            speakers=speakers,
            on_preview_voice=self._preview_voice,
            theme_manager=self._theme_manager,
            parent=None,  # постоянного окна у приложения нет
        )
        dialog.on_saved = self._apply_settings
        # Правки ударений сохраняются из вкладки сразу, мимо «Сохранить»:
        # их надо применить к живому акцентору, иначе правка не сработает.
        dialog.on_corrections_changed = self._reload_stress
        dialog.on_edit_abbreviations = self.open_abbreviations
        self._settings_dialog = dialog
        dialog.connect("destroy", self._on_settings_closed)
        dialog.connect("close-request", self._on_settings_close_request)
        dialog.present()

    def _on_settings_close_request(self, dialog) -> bool:
        """Закрытие всегда уничтожает окно: скрытое окно путало повторный запуск."""
        self._settings_dialog = None
        dialog.destroy()
        return True    # уничтожение уже выполнено, стандартный обработчик не нужен

    def _on_settings_closed(self, *_args) -> None:
        self._settings_dialog = None

    def _apply_settings(self) -> None:
        if self._theme_manager is not None:
            self._theme_manager.use_system_accent = self._config.use_system_accent
            self._theme_manager.set_mode(self._config.theme)
        self._update_widget_theme()
        self._register_hotkeys()
        if self._widget is not None:
            self._widget.set_positioning(self._config.window_positioning)
        # Значок трея мог сменить вариант цвета: переставляем без перезапуска.
        if self._widget is not None:
            self._widget.set_speed(self._config.speed)

    def open_abbreviations(self) -> None:
        """Открыть редактор сокращений и применить правки после сохранения."""
        if self._abbrev_dialog is not None:
            self._abbrev_dialog.present()
            return

        dialog = AbbrevWindow(
            self._widget or None, self._config.abbrev_file)
        self._abbrev_dialog = dialog
        dialog.connect("response", self._on_abbrev_closed)
        dialog.present()

    def _on_abbrev_closed(self, dialog, response: int) -> None:
        self._abbrev_dialog = None
        if response == Gtk.ResponseType.OK:
            # Правки прочитаны с диска, а не из окна: так работает и правка
            # файла руками, пока окно было открыто.
            self._engine.reload_abbreviations(
                load_abbrev_extra(self._config.abbrev_file))
            self._notify(_("Сокращения сохранены"))

    def _reload_stress(self) -> None:
        """Перечитать правки ударений в живом движке.

        Акцентор создаётся при первой фразе и держит свод правок в памяти,
        поэтому после вкладки «Правки ударений» его надо разбудить — иначе
        сохранённая правка не подействует до перезапуска.
        """
        self._engine.reload_accents(load_overrides(self._config.stress_file))

    def _preview_voice(self, speaker: str, speed: float) -> None:
        self._stop_playback_sync()
        self._begin_pipeline(
            _("Привет! Это голос {speaker} со скоростью {speed}x.").format(
                speaker=speaker, speed=f"{speed:.2g}"),
            speaker=speaker,
            speed=speed,
        )

    # ── Уведомления и диалоги ────────────────────────────────────────────────

    def _notify(self, message: str, title: str = APP_NAME) -> None:
        """Всплывающее уведомление: работает и без трея (Gio.Notification)."""
        notification = Gio.Notification.new(title)
        notification.set_body(message)
        path = icon_file()
        if path:
            notification.set_icon(Gio.FileIcon.new(Gio.File.new_for_path(path)))
        else:
            notification.set_icon(Gio.ThemedIcon.new("audio-headset"))
        try:
            self.send_notification(None, notification)
        except Exception:
            print(f"[{title}] {message}", flush=True)

    def _show_tts_error(self, error_text: str) -> None:
        dialog = Gtk.MessageDialog(
            transient_for=None,
            modal=True,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.CLOSE,
            text=_("Не удалось синтезировать речь"),
        )
        dialog.set_title(_("Ошибка TTS"))
        dialog.format_secondary_text(error_text)
        # В GTK4 у диалога нет run(): показываем и закрываем по ответу.
        dialog.connect("response", lambda d, _r: d.destroy())
        dialog.present()

    def _show_about(self) -> None:
        """Окно «О программе».

        В GTK4 у диалогов нет ``run()``: он блокировал цикл и удалён. Диалог
        показывается через ``present()``, а уничтожается по сигналу ``close``.
        Ссылка хранится на приложении: без неё диалог уходит в сборщик
        мусора, как и диалог выбора файла.
        """
        if self._about_dialog is not None:
            self._about_dialog.present()
            return

        dialog = Gtk.AboutDialog(modal=False)
        dialog.set_program_name(APP_NAME)
        dialog.set_version(APP_VERSION)
        dialog.set_comments(_(
            "Озвучивание выделенного текста с помощью Silero TTS.\n"
            "Горячие клавиши и голос настраиваются в Настройках."
        ))
        path = icon_file()
        if path:
            with contextlib.suppress(Exception):
                # В GTK4 set_logo ждёт Gdk.Paintable: GdkPixbuf.Pixbuf даёт
                # TypeError, и значок молча не появлялся. Texture — Paintable.
                dialog.set_logo(Gdk.Texture.new_from_filename(path))

        def on_close(window) -> bool:
            self._about_dialog = None
            return False    # стандартное закрытие: окно уничтожается само

        dialog.connect("close-request", on_close)
        dialog.connect("destroy", lambda *_a: setattr(self, "_about_dialog", None))
        self._about_dialog = dialog
        dialog.present()

    # ── Позиция виджета ──────────────────────────────────────────────────────

    def _save_widget_position(self) -> bool:
        """Позиция не сохраняется: в GTK4 её нельзя ни узнать, ни задать.

        Место окна выбирает композитор (через layer-shell) либо X-сервер по
        нашей просьбе — прочитать его обратно нечем, а значит и запоминать
        нечего. Настройка widget.position_* остаётся ради старых конфигов.
        """
        return True  # повторяющийся таймер

    # ── Выход ────────────────────────────────────────────────────────────────

    def _quit(self) -> None:
        instance.clear()
        self._stop_playback_sync()
        self._hotkey_listener.stop_listening()
        self._config.save()
        if self._position_timer is not None:
            GLib.source_remove(self._position_timer)
            self._position_timer = None
        if self._tray is not None:
            self._tray.hide()
        self.release()
        self.quit()
